export const dashboardNavigation = [
  { label: "Dashboard", href: "/admin/dashboard" },
  { label: "Hero", href: "/admin/hero" },
  { label: "Kenapa Memilih Kami", href: "/admin/features" },
  { label: "Galeri", href: "/admin/gallery" },
  { label: "Pengaturan", href: "/admin/settings" },
] as const;
