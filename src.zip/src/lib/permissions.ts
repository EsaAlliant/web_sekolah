export function hasPermission(_permission: string) { return false; }
