"use client";
import { createContext, useContext } from "react";
export type Theme = "light" | "dark" | "system";
export interface ThemeContextValue { theme: Theme; setTheme: (theme: Theme) => void; }
export const ThemeContext = createContext<ThemeContextValue | null>(null);
export function useThemeContext() { const context = useContext(ThemeContext); if (!context) throw new Error("useTheme must be used within ThemeProvider"); return context; }
