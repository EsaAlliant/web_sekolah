import Link from "next/link";
import { createServerClient } from "@/lib/supabase/server";

const editableModules = [
  { label: "Hero (Slide Beranda)", href: "/admin/hero", icon: "bi-images", table: "hero_slides" },
  { label: "Kenapa Memilih Kami", href: "/admin/features", icon: "bi-star", table: "homepage_features" },
  { label: "Galeri", href: "/admin/gallery", icon: "bi-image", table: "gallery_items" },
  { label: "Pengaturan Situs & Logo", href: "/admin/settings", icon: "bi-gear", table: null },
];

const comingSoonModules = [
  { label: "Guru", table: "teachers" },
  { label: "Staff", table: "staff" },
  { label: "Jurusan", table: "majors" },
  { label: "Agenda", table: "agenda_events" },
  { label: "Berita", table: "news" },
  { label: "Pengumuman", table: "announcements" },
  { label: "Testimoni", table: "testimonials" },
  { label: "Pendaftar PPDB", table: "ppdb_submissions" },
];

export default async function AdminDashboardPage() {
  const supabase = await createServerClient();
  const { data: { user } } = await supabase.auth.getUser();

  const allModules = [...editableModules, ...comingSoonModules];
  const counts = await Promise.all(
    allModules
      .filter((module) => module.table)
      .map(async (module) => {
        const { count } = await supabase.from(module.table as string).select("*", { count: "exact", head: true });
        return { table: module.table, count: count ?? 0 };
      }),
  );
  const countByTable = Object.fromEntries(counts.map((item) => [item.table, item.count]));

  return (
    <div>
      <h1 className="h4 mb-1">Selamat datang, {user?.email}</h1>
      <p className="text-muted-strong mb-4">Kelola konten yang tampil di halaman Beranda dan situs sekolah.</p>

      <h2 className="h6 text-muted-strong mb-3">Bisa Dikelola Sekarang</h2>
      <div className="row g-3 mb-5">
        {editableModules.map((module) => (
          <div className="col-6 col-md-3" key={module.href}>
            <Link className="admin-module-card" href={module.href}>
              <i aria-hidden="true" className={`bi ${module.icon}`} />
              <strong>{module.label}</strong>
              {module.table && <span>{countByTable[module.table] ?? 0} data</span>}
            </Link>
          </div>
        ))}
      </div>

      <h2 className="h6 text-muted-strong mb-3">Segera Hadir (Formulir CRUD Belum Dibuat)</h2>
      <div className="row g-3">
        {comingSoonModules.map((module) => (
          <div className="col-6 col-md-3" key={module.table}>
            <div className="admin-stat-card">
              <strong>{countByTable[module.table] ?? 0}</strong>
              <span>{module.label}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="alert alert-info mt-4 mb-0">
        <i aria-hidden="true" className="bi bi-info-circle" /> Modul di bagian "Segera Hadir" datanya sudah ada di
        database dan sudah tampil di situs publik, tapi belum bisa diedit lewat form di sini — masih lewat Supabase
        Table Editor.
      </div>
    </div>
  );
}
