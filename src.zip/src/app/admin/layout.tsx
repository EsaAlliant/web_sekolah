import { redirect } from "next/navigation";
import { Header } from "@/components/layout/Header/Header";
import { Sidebar } from "@/components/layout/Sidebar/Sidebar";
import { createServerClient } from "@/lib/supabase/server";

export default async function AdminLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const supabase = await createServerClient();
  const { data: { user } } = await supabase.auth.getUser();

  // Lapisan pengaman kedua di samping middleware — kalau entah bagaimana
  // lolos dari middleware, halaman admin tetap tidak akan pernah dirender
  // tanpa user yang valid.
  if (!user) {
    redirect("/auth/login");
  }

  return (
    <div className="admin-shell">
      <Sidebar />
      <div className="admin-content">
        <Header userEmail={user.email} />
        <main className="container-fluid py-4">{children}</main>
      </div>
    </div>
  );
}
