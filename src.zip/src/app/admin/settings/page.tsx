import { LogoSettingsForm } from "@/components/directory/LogoSettingsForm";
import { getWebsiteSettings } from "@/services/settings.service";

export default async function AdminSettingsPage() {
  const settings = await getWebsiteSettings();

  return (
    <div>
      <h1 className="h4 mb-4">Pengaturan Situs</h1>

      <div className="admin-stat-card text-start" style={{ maxWidth: "24rem" }}>
        <h2 className="h6 mb-3">Logo Sekolah</h2>
        <LogoSettingsForm currentLogoUrl={settings.logoUrl} />
        <p className="text-muted-strong small mt-3 mb-0">Format PNG/WebP/SVG, disarankan persegi dengan latar transparan, maksimal 5MB.</p>
      </div>
    </div>
  );
}
