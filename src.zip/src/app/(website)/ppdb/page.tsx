import { PlaceholderPage } from "@/components/common/PlaceholderPage";
export default function PpdbPage() { return <PlaceholderPage title="PPDB" />; }
