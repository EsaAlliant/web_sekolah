import type { Metadata } from "next";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "@fortawesome/fontawesome-svg-core/styles.css";
import "@/lib/fontawesome";
import "@/styles/variables.css";
import "@/styles/utilities.css";
import "@/styles/animations.css";
import "@/styles/bootstrap-overrides.css";
import "@/styles/website-layout.css";
import "./globals.css";
import { AppProviders } from "@/providers/AppProviders";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: { default: siteConfig.name, template: `%s | ${siteConfig.name}` },
  description: siteConfig.description,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body>
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
