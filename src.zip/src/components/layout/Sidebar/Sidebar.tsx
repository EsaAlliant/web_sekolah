"use client";
import Link from "next/link";
import { dashboardNavigation } from "@/config/dashboard";
import { useSidebar } from "@/hooks/useSidebar";
export function Sidebar() { const { isOpen } = useSidebar(); return <aside className={`admin-sidebar ${isOpen ? "is-open" : ""}`}><span className="fw-semibold d-block mb-3">Admin Sekolah</span>{dashboardNavigation.map((item) => <Link href={item.href} key={item.href}>{item.label}</Link>)}</aside>; }
