"use client";
import { useState } from "react";
export function useModal(initialOpen = false) { const [isOpen, setIsOpen] = useState(initialOpen); return { isOpen, open: () => setIsOpen(true), close: () => setIsOpen(false) }; }
